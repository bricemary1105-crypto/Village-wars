# 🏰 Kingdoms — Jeu médiéval pour camp

Application mobile hors-ligne pour animer un camp sur le thème chevaliers et moyen âge.

## 🎮 Comment ça marche

Chaque équipe a son propre téléphone avec l'application. Les animateurs font passer des épreuves en vrai, et récompensent les équipes en **pièces d'or** via un code secret. Les équipes utilisent leurs pièces pour construire et embellir leur village médiéval. **L'équipe avec le plus beau village gagne !**

## ✨ Fonctionnalités

- 🏘️ **Village** — Grille 6x6 qui se remplit avec les bâtiments achetés
- 🛒 **Boutique** — 12 bâtiments en 5 catégories (Nature, Déco, Commerce, Habitation, Monuments)
- 🏆 **Classement** — Affichage du score de beauté
- 🔐 **Code Animateur** — Les animateurs entrent un code secret pour attribuer des pièces d'or

## 🔐 Code animateur par défaut

```
CHEVALIER2024
```

> Pour changer le code, modifie la ligne `const ADMIN_CODE = "CHEVALIER2024";` dans `src/App.js`

## 🚀 Installation

### Prérequis
- [Node.js](https://nodejs.org/) (version 16 ou plus)
- npm (inclus avec Node.js)

### Étapes

```bash
# 1. Clone le projet
git clone https://github.com/TON-USERNAME/kingdoms.git
cd kingdoms

# 2. Installe les dépendances
npm install

# 3. Lance en développement
npm start
```

L'app s'ouvre automatiquement sur `http://localhost:3000`

## 📱 Déployer sur téléphone (pour le camp)

### Option A — Vercel (recommandé, gratuit)
1. Crée un compte sur [vercel.com](https://vercel.com)
2. Connecte ton GitHub
3. Importe le projet → Vercel déploie automatiquement
4. Chaque équipe ouvre le lien sur son téléphone

### Option B — Build local
```bash
npm run build
```
Puis sers le dossier `build/` avec n'importe quel serveur HTTP local.

## 🏰 Bâtiments disponibles

| Catégorie   | Bâtiment        | Coût 🪙 | Beauté ✨ |
|-------------|-----------------|---------|----------|
| 🌿 Nature   | Buisson         | 10      | 2        |
| 🌿 Nature   | Fleurs          | 15      | 3        |
| 🌿 Nature   | Jardin Royal    | 30      | 6        |
| ⛲ Déco     | Lanterne        | 25      | 5        |
| ⛲ Déco     | Fontaine        | 40      | 8        |
| ⛲ Déco     | Statue          | 50      | 10       |
| 🏪 Commerce | Marché          | 60      | 7        |
| 🏪 Commerce | Taverne         | 70      | 9        |
| 🏠 Maisons  | Maison          | 30      | 5        |
| 🏠 Maisons  | Manoir          | 90      | 15       |
| 🏰 Monuments| Église          | 100     | 18       |
| 🏰 Monuments| Château         | 200     | 40       |

## 📁 Structure du projet

```
kingdoms/
├── public/
│   └── index.html
├── src/
│   ├── App.js       ← Toute la logique du jeu
│   └── index.js
├── package.json
└── README.md
```

## 🛠️ Personnalisation

Tu peux facilement modifier dans `src/App.js` :
- **Code animateur** : ligne `const ADMIN_CODE = "..."`
- **Bâtiments** : tableau `BUILDINGS` (ajouter/modifier/supprimer)
- **Pièces de départ** : `useState(50)` → change `50`

---

Fait avec ❤️ pour les camps de chevaliers 🏰⚔️
