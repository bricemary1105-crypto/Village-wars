import { useState } from "react";

// ============================================================
//  CODE ANIMATEUR — change cette valeur si tu veux
// ============================================================
const ADMIN_CODE = "CHEVALIER2024";

// ============================================================
//  BÂTIMENTS DISPONIBLES
// ============================================================
const BUILDINGS = [
  { id: "buisson",  name: "Buisson",       emoji: "🌿", cost: 10,  beauty: 2,  category: "nature"     },
  { id: "fleurs",   name: "Fleurs",         emoji: "🌸", cost: 15,  beauty: 3,  category: "nature"     },
  { id: "jardin",   name: "Jardin Royal",   emoji: "🌳", cost: 30,  beauty: 6,  category: "nature"     },
  { id: "fontaine", name: "Fontaine",       emoji: "⛲", cost: 40,  beauty: 8,  category: "decoration" },
  { id: "statue",   name: "Statue",         emoji: "🗿", cost: 50,  beauty: 10, category: "decoration" },
  { id: "lanterne", name: "Lanterne",       emoji: "🏮", cost: 25,  beauty: 5,  category: "decoration" },
  { id: "marche",   name: "Marché",         emoji: "🏪", cost: 60,  beauty: 7,  category: "commerce"   },
  { id: "taverne",  name: "Taverne",        emoji: "🍺", cost: 70,  beauty: 9,  category: "commerce"   },
  { id: "maison",   name: "Maison",         emoji: "🏠", cost: 30,  beauty: 5,  category: "habitation" },
  { id: "manoir",   name: "Manoir",         emoji: "🏡", cost: 90,  beauty: 15, category: "habitation" },
  { id: "eglise",   name: "Église",         emoji: "⛪", cost: 100, beauty: 18, category: "monument"   },
  { id: "chateau",  name: "Château",        emoji: "🏰", cost: 200, beauty: 40, category: "monument"   },
];

const CATEGORIES = [
  { id: "nature",     label: "🌿 Nature"    },
  { id: "decoration", label: "⛲ Déco"      },
  { id: "commerce",   label: "🏪 Commerce"  },
  { id: "habitation", label: "🏠 Maisons"   },
  { id: "monument",   label: "🏰 Monuments" },
];

// ============================================================
//  COMPOSANT PRINCIPAL
// ============================================================
export default function App() {
  const [screen,      setScreen]      = useState("home");
  const [teamName,    setTeamName]    = useState("");
  const [setupName,   setSetupName]   = useState("");
  const [coins,       setCoins]       = useState(50);
  const [purchased,   setPurchased]   = useState([]);
  const [activeTab,   setActiveTab]   = useState("nature");
  const [adminOpen,   setAdminOpen]   = useState(false);
  const [adminStep,   setAdminStep]   = useState("code");
  const [adminCode,   setAdminCode]   = useState("");
  const [adminAmount, setAdminAmount] = useState("");
  const [adminError,  setAdminError]  = useState("");
  const [notif,       setNotif]       = useState(null);

  const beauty = purchased.reduce((sum, id) => {
    const b = BUILDINGS.find((b) => b.id === id);
    return sum + (b ? b.beauty : 0);
  }, 0);

  const showNotif = (msg, type = "ok") => {
    setNotif({ msg, type });
    setTimeout(() => setNotif(null), 2500);
  };

  const buy = (b) => {
    if (coins < b.cost) return showNotif("Pas assez de pièces ! 😢", "err");
    setCoins((c) => c - b.cost);
    setPurchased((p) => [...p, b.id]);
    showNotif(`${b.emoji} ${b.name} construit !`);
  };

  const openAdmin = () => {
    setAdminOpen(true);
    setAdminStep("code");
    setAdminCode("");
    setAdminAmount("");
    setAdminError("");
  };

  const validateCode = () => {
    if (adminCode === ADMIN_CODE) { setAdminStep("amount"); setAdminError(""); }
    else setAdminError("Code incorrect !");
  };

  const validateAmount = () => {
    const n = parseInt(adminAmount);
    if (!n || n <= 0) return setAdminError("Montant invalide !");
    setCoins((c) => c + n);
    setAdminOpen(false);
    showNotif(`+${n} pièces d'or reçues ! 🪙`);
  };

  const grid = Array(30).fill(null).map((_, i) => purchased[i] || null);

  // ── HOME ──────────────────────────────────────────────────
  if (screen === "home") return (
    <div style={s.home}>
      <div style={{ fontSize: 80, filter: "drop-shadow(0 0 24px #f59e0b)", marginBottom: 8 }}>🏰</div>
      <h1 style={s.homeTitle}>Kingdoms</h1>
      <p style={s.homeSub}>Construisez le plus beau village médiéval</p>
      <div style={s.homeLine} />
      <button style={s.homeBtn} onClick={() => setScreen("setup")}>⚔️ Commencer l'aventure</button>
      <p style={s.homeFooter}>Camp des Chevaliers • Hors-ligne</p>
    </div>
  );

  // ── SETUP ─────────────────────────────────────────────────
  if (screen === "setup") return (
    <div style={s.setupWrap}>
      <div style={s.setupCard}>
        <div style={{ fontSize: 48, marginBottom: 12 }}>⚜️</div>
        <h2 style={{ color: "#f59e0b", marginBottom: 24, fontSize: 20 }}>Baptisez votre Royaume</h2>
        <input
          value={setupName}
          onChange={e => setSetupName(e.target.value)}
          placeholder="Nom de votre équipe..."
          maxLength={20}
          style={s.input}
        />
        <button
          disabled={!setupName.trim()}
          onClick={() => { setTeamName(setupName.trim()); setScreen("village"); }}
          style={{ ...s.primaryBtn, opacity: setupName.trim() ? 1 : 0.4 }}
        >
          Fonder le Royaume 🏰
        </button>
      </div>
    </div>
  );

  // ── MAIN APP ──────────────────────────────────────────────
  return (
    <div style={s.app}>

      {/* Notification */}
      {notif && (
        <div style={{ ...s.notif, background: notif.type === "err" ? "#7f1d1d" : "#14532d" }}>
          {notif.msg}
        </div>
      )}

      {/* Header */}
      <div style={s.header}>
        <div>
          <div style={{ fontSize: 17, fontWeight: "bold", color: "#f59e0b" }}>{teamName}</div>
          <div style={{ fontSize: 12, color: "#d97706" }}>✨ Beauté : {beauty} pts</div>
        </div>
        <div style={s.coinBadge}>
          <span style={{ fontSize: 20 }}>🪙</span>
          <span style={{ fontSize: 20, fontWeight: "bold", color: "#f59e0b" }}>{coins}</span>
        </div>
      </div>

      {/* Navigation */}
      <div style={s.nav}>
        {[["village","🏘️ Village"],["shop","🛒 Boutique"],["ranking","🏆 Classement"]].map(([sc, label]) => (
          <button key={sc} onClick={() => setScreen(sc)}
            style={{ ...s.navBtn, ...(screen === sc ? s.navBtnActive : {}) }}>
            {label}
          </button>
        ))}
      </div>

      <div style={{ padding: 16 }}>

        {/* ── VILLAGE ── */}
        {screen === "village" && <>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:14 }}>
            <h2 style={s.title}>Votre Village</h2>
            <span style={s.beautyBadge}>✨ {beauty} pts</span>
          </div>

          {/* Grille du village */}
          <div style={s.grid}>
            {grid.map((cell, i) => {
              const b = cell ? BUILDINGS.find(x => x.id === cell) : null;
              return (
                <div key={i} style={{ ...s.cell, ...(b ? s.cellFilled : {}) }}>
                  <span style={{ fontSize: b ? 18 : 14 }}>{b ? b.emoji : "·"}</span>
                </div>
              );
            })}
          </div>

          {/* Stats */}
          <div style={{ display:"flex", gap:10, marginBottom:14 }}>
            {[["🏗️", purchased.length, "Bâtiments"],["🪙", coins, "Pièces"],["✨", beauty, "Beauté"]].map(([icon,val,label]) => (
              <div key={label} style={s.statCard}>
                <div style={{ fontSize:22, fontWeight:"bold", color:"#f59e0b" }}>{val}</div>
                <div style={{ fontSize:11, color:"#a16207" }}>{label}</div>
              </div>
            ))}
          </div>

          <button onClick={openAdmin} style={s.adminBtn}>🔐 Code Animateur</button>
        </>}

        {/* ── BOUTIQUE ── */}
        {screen === "shop" && <>
          <h2 style={s.title}>Boutique du Royaume</h2>
          <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:14 }}>
            {CATEGORIES.map(cat => (
              <button key={cat.id} onClick={() => setActiveTab(cat.id)}
                style={{ ...s.tab, ...(activeTab === cat.id ? s.tabActive : {}) }}>
                {cat.label}
              </button>
            ))}
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
            {BUILDINGS.filter(b => b.category === activeTab).map(b => (
              <div key={b.id} style={s.shopCard}>
                <div style={{ fontSize:34, marginBottom:6 }}>{b.emoji}</div>
                <div style={{ fontSize:14, color:"#f5e0b0", marginBottom:4 }}>{b.name}</div>
                <div style={{ fontSize:12, color:"#d97706", marginBottom:10 }}>✨ +{b.beauty} beauté</div>
                <button onClick={() => buy(b)}
                  style={{ ...s.primaryBtn, opacity: coins >= b.cost ? 1 : 0.4, fontSize:13, padding:"8px" }}>
                  🪙 {b.cost}
                </button>
              </div>
            ))}
          </div>
        </>}

        {/* ── CLASSEMENT ── */}
        {screen === "ranking" && <>
          <h2 style={s.title}>Classement</h2>
          <p style={{ color:"#a16207", fontStyle:"italic", fontSize:13, marginBottom:20 }}>
            Le classement final sera révélé par les animateurs à la fin du camp.
          </p>
          <div style={s.rankCard}>
            <div style={{ fontSize:50, marginBottom:8 }}>👑</div>
            <div style={{ fontSize:22, fontWeight:"bold", color:"#f59e0b", marginBottom:8 }}>{teamName}</div>
            <div style={{ fontSize:18, marginBottom:4 }}>✨ {beauty} points de beauté</div>
            <div style={{ fontSize:13, color:"#a16207" }}>{purchased.length} bâtiments construits</div>
          </div>
          <div style={s.tip}>💡 Achetez des Monuments pour maximiser votre score de beauté !</div>
        </>}

      </div>

      {/* ── MODAL ANIMATEUR ── */}
      {adminOpen && (
        <div onClick={() => setAdminOpen(false)} style={s.overlay}>
          <div onClick={e => e.stopPropagation()} style={s.modal}>
            <div style={{ fontSize:20, color:"#f59e0b", textAlign:"center", marginBottom:20 }}>🔐 Espace Animateur</div>
            {adminStep === "code" ? <>
              <p style={s.modalLabel}>Code secret :</p>
              <input type="password" value={adminCode} onChange={e => setAdminCode(e.target.value)}
                placeholder="Entrez le code..." style={s.input}
                onKeyDown={e => e.key === "Enter" && validateCode()} />
              {adminError && <div style={s.error}>{adminError}</div>}
              <button onClick={validateCode} style={s.primaryBtn}>Valider</button>
            </> : <>
              <p style={s.modalLabel}>Pièces d'or à attribuer :</p>
              <input type="number" value={adminAmount} onChange={e => setAdminAmount(e.target.value)}
                placeholder="Ex: 50" style={s.input}
                onKeyDown={e => e.key === "Enter" && validateAmount()} />
              {adminError && <div style={s.error}>{adminError}</div>}
              <button onClick={validateAmount} style={s.primaryBtn}>Attribuer 🪙</button>
            </>}
            <button onClick={() => setAdminOpen(false)} style={s.cancelBtn}>Annuler</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================
//  STYLES
// ============================================================
const s = {
  app:        { minHeight:"100vh", background:"#1a0800", color:"#f5e0b0", fontFamily:"Georgia,serif", paddingBottom:24 },
  home:       { minHeight:"100vh", background:"linear-gradient(160deg,#1a0800,#3d1a00,#1a0800)", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", fontFamily:"Georgia,serif", color:"#f5e0b0", textAlign:"center", padding:24, position:"relative" },
  homeTitle:  { fontSize:38, color:"#f59e0b", letterSpacing:5, margin:"0 0 8px", textTransform:"uppercase" },
  homeSub:    { color:"#d97706", fontStyle:"italic", marginBottom:32, fontSize:14 },
  homeLine:   { width:60, height:2, background:"#f59e0b", margin:"0 auto 32px" },
  homeBtn:    { background:"linear-gradient(135deg,#b45309,#f59e0b)", border:"none", borderRadius:14, padding:"16px 44px", fontSize:18, color:"#1a0800", fontWeight:"bold", cursor:"pointer", fontFamily:"Georgia,serif", boxShadow:"0 6px 24px rgba(245,158,11,.4)" },
  homeFooter: { position:"absolute", bottom:20, color:"#78350f", fontSize:11 },
  setupWrap:  { minHeight:"100vh", background:"linear-gradient(160deg,#1a0800,#3d1a00)", display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"Georgia,serif", padding:24 },
  setupCard:  { background:"rgba(255,255,255,.05)", border:"1px solid rgba(245,158,11,.25)", borderRadius:20, padding:36, width:"100%", maxWidth:320, textAlign:"center" },
  header:     { background:"linear-gradient(90deg,#2d1200,#3d1a00)", padding:"14px 18px", display:"flex", justifyContent:"space-between", alignItems:"center", borderBottom:"1px solid #b45309" },
  coinBadge:  { display:"flex", alignItems:"center", gap:6, background:"rgba(245,158,11,.15)", padding:"8px 14px", borderRadius:20, border:"1px solid #b45309" },
  nav:        { display:"flex", background:"#2d1200", borderBottom:"1px solid #78350f" },
  navBtn:     { flex:1, padding:"12px 4px", border:"none", background:"transparent", color:"#a16207", fontSize:12, cursor:"pointer", fontFamily:"Georgia,serif" },
  navBtnActive:{ color:"#f59e0b", borderBottom:"2px solid #f59e0b", background:"rgba(245,158,11,.1)", fontWeight:"bold" },
  title:      { color:"#f59e0b", fontSize:18, margin:0 },
  beautyBadge:{ background:"rgba(245,158,11,.2)", border:"1px solid #f59e0b", borderRadius:20, padding:"4px 12px", fontSize:13, color:"#f59e0b" },
  grid:       { display:"grid", gridTemplateColumns:"repeat(6,1fr)", gap:4, background:"#2d1200", borderRadius:12, padding:10, border:"1px solid #78350f", marginBottom:14 },
  cell:       { aspectRatio:"1", borderRadius:6, background:"#1a0800", border:"1px solid #3d1a00", display:"flex", alignItems:"center", justifyContent:"center" },
  cellFilled: { background:"rgba(245,158,11,.12)", border:"1px solid #b45309" },
  statCard:   { flex:1, background:"#2d1200", borderRadius:10, padding:"12px 8px", textAlign:"center", border:"1px solid #78350f" },
  adminBtn:   { width:"100%", padding:14, background:"rgba(255,255,255,.04)", border:"1px solid #78350f", borderRadius:10, color:"#a16207", fontSize:14, cursor:"pointer", fontFamily:"Georgia,serif" },
  tab:        { padding:"6px 12px", borderRadius:20, border:"1px solid #78350f", background:"transparent", color:"#a16207", fontSize:12, cursor:"pointer", fontFamily:"Georgia,serif" },
  tabActive:  { background:"rgba(245,158,11,.2)", border:"1px solid #f59e0b", color:"#f59e0b" },
  shopCard:   { background:"#2d1200", borderRadius:12, padding:14, textAlign:"center", border:"1px solid #78350f" },
  rankCard:   { background:"linear-gradient(135deg,#2d1200,#3d1a00)", borderRadius:16, padding:24, textAlign:"center", border:"1px solid #b45309", marginBottom:14 },
  tip:        { background:"rgba(245,158,11,.08)", border:"1px solid #78350f", borderRadius:10, padding:14, color:"#d97706", fontSize:13 },
  notif:      { position:"fixed", top:16, left:"50%", transform:"translateX(-50%)", color:"#fff", padding:"12px 24px", borderRadius:20, fontSize:14, zIndex:999, whiteSpace:"nowrap", boxShadow:"0 4px 20px rgba(0,0,0,.5)" },
  overlay:    { position:"fixed", inset:0, background:"rgba(0,0,0,.85)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:998, padding:24 },
  modal:      { background:"#2d1200", borderRadius:16, padding:28, width:"100%", maxWidth:320, border:"1px solid #b45309" },
  modalLabel: { color:"#d97706", fontSize:14, marginBottom:8 },
  input:      { width:"100%", padding:"12px 14px", borderRadius:10, border:"1px solid #b45309", background:"#1a0800", color:"#f5e0b0", fontSize:16, fontFamily:"Georgia,serif", marginBottom:12, boxSizing:"border-box" },
  primaryBtn: { width:"100%", padding:12, background:"linear-gradient(135deg,#b45309,#f59e0b)", border:"none", borderRadius:8, color:"#1a0800", fontWeight:"bold", fontSize:16, cursor:"pointer", marginBottom:8, fontFamily:"Georgia,serif" },
  cancelBtn:  { width:"100%", padding:10, background:"transparent", border:"1px solid #78350f", borderRadius:8, color:"#a16207", fontSize:14, cursor:"pointer", fontFamily:"Georgia,serif" },
  error:      { color:"#ef4444", fontSize:13, marginBottom:8 },
};
